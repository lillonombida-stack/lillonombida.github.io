package com.example.taskapi.service;

import com.example.taskapi.dto.TaskRequest;
import com.example.taskapi.dto.TaskResponse;
import com.example.taskapi.entity.TaskStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TaskService {

    TaskResponse create(TaskRequest request);

    TaskResponse getById(Long id);

    Page<TaskResponse> list(TaskStatus status, String titleContains, Pageable pageable);

    TaskResponse update(Long id, TaskRequest request);

    void delete(Long id);
}
