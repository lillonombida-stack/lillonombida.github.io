package com.example.taskapi.dto;

import com.example.taskapi.entity.TaskStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

@Schema(description = "Payload for creating or updating a task")
public record TaskRequest(

        @Schema(description = "Task title", example = "Write quarterly report")
        @NotBlank(message = "Title is required")
        @Size(max = 150, message = "Title must be at most 150 characters")
        String title,

        @Schema(description = "Optional task details", example = "Summarize Q3 metrics for leadership")
        @Size(max = 2000, message = "Description must be at most 2000 characters")
        String description,

        @Schema(description = "Current status; defaults to PENDING if omitted")
        TaskStatus status,

        @Schema(description = "Due date, must be today or in the future", example = "2026-10-01")
        @FutureOrPresent(message = "Due date cannot be in the past")
        LocalDate dueDate
) {
}
