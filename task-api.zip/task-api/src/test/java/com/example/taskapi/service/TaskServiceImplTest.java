package com.example.taskapi.service;

import com.example.taskapi.dto.TaskRequest;
import com.example.taskapi.dto.TaskResponse;
import com.example.taskapi.entity.Task;
import com.example.taskapi.entity.TaskStatus;
import com.example.taskapi.exception.ResourceNotFoundException;
import com.example.taskapi.mapper.TaskMapper;
import com.example.taskapi.repository.TaskRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskServiceImplTest {

    @Mock
    private TaskRepository taskRepository;

    @InjectMocks
    private TaskServiceImpl taskService;

    private final TaskMapper taskMapper = new TaskMapper();

    @BeforeEach
    void setUp() {
        // Inject the real mapper since it has no dependencies of its own.
        taskService = new TaskServiceImpl(taskRepository, taskMapper);
    }

    @Test
    void create_savesAndReturnsMappedResponse() {
        TaskRequest request = new TaskRequest("Write report", "Q3 summary", TaskStatus.PENDING, LocalDate.now().plusDays(1));
        Task persisted = Task.builder()
                .id(1L)
                .title(request.title())
                .description(request.description())
                .status(TaskStatus.PENDING)
                .dueDate(request.dueDate())
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .build();
        when(taskRepository.save(any(Task.class))).thenReturn(persisted);

        TaskResponse response = taskService.create(request);

        assertThat(response.id()).isEqualTo(1L);
        assertThat(response.title()).isEqualTo("Write report");
        assertThat(response.status()).isEqualTo(TaskStatus.PENDING);
        verify(taskRepository, times(1)).save(any(Task.class));
    }

    @Test
    void getById_whenTaskExists_returnsResponse() {
        Task task = Task.builder().id(5L).title("Existing").status(TaskStatus.IN_PROGRESS)
                .createdAt(Instant.now()).updatedAt(Instant.now()).build();
        when(taskRepository.findById(5L)).thenReturn(Optional.of(task));

        TaskResponse response = taskService.getById(5L);

        assertThat(response.id()).isEqualTo(5L);
        assertThat(response.status()).isEqualTo(TaskStatus.IN_PROGRESS);
    }

    @Test
    void getById_whenTaskMissing_throwsNotFound() {
        when(taskRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> taskService.getById(99L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void delete_whenTaskMissing_throwsNotFound() {
        when(taskRepository.findById(42L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> taskService.delete(42L))
                .isInstanceOf(ResourceNotFoundException.class);

        verify(taskRepository, never()).delete(any(Task.class));
    }

    @Test
    void delete_whenTaskExists_removesIt() {
        Task task = Task.builder().id(7L).title("To delete").status(TaskStatus.PENDING).build();
        when(taskRepository.findById(7L)).thenReturn(Optional.of(task));

        taskService.delete(7L);

        verify(taskRepository, times(1)).delete(task);
    }
}
