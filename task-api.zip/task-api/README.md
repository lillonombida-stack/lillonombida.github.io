# Task Management REST API

A production-style Java REST API built with Spring Boot 3, demonstrating a clean
layered architecture, validation, centralized error handling, pagination,
OpenAPI documentation, and tests.

## Stack

- Java 17, Spring Boot 3.3
- Spring Web, Spring Data JPA, Bean Validation
- H2 in-memory database (swap for Postgres/MySQL in production — see below)
- springdoc-openapi (Swagger UI)
- Lombok
- JUnit 5, Mockito, MockMvc

## Architecture

```
controller/   → REST endpoints, request/response mapping, HTTP concerns only
service/      → business logic, transactions
repository/   → Spring Data JPA data access
entity/       → JPA entities
dto/          → request/response payloads (records), decoupled from entities
mapper/       → entity <-> DTO conversion
exception/    → custom exceptions + @RestControllerAdvice global handler
config/       → OpenAPI/Swagger configuration
```

Controllers never touch entities directly — everything crosses the boundary as
a DTO, so the persistence model can evolve without breaking the API contract.

## Running locally

```bash
mvn spring-boot:run
```

The API starts on `http://localhost:8080`.

- Swagger UI: `http://localhost:8080/swagger-ui.html`
- OpenAPI JSON: `http://localhost:8080/v3/api-docs`
- H2 console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:taskdb`)
- Health check: `http://localhost:8080/actuator/health`

## Running with Docker

```bash
docker build -t task-api .
docker run -p 8080:8080 task-api
```

## Running tests

```bash
mvn test
```

Includes unit tests for the service layer (Mockito) and integration tests for
the controller layer (`@SpringBootTest` + `MockMvc`), covering the happy path,
validation failures, and 404s.

## API Reference

Base path: `/api/v1/tasks`

| Method | Path              | Description                                   |
|--------|-------------------|------------------------------------------------|
| POST   | `/`               | Create a task                                  |
| GET    | `/{id}`           | Get a task by id                               |
| GET    | `/`               | List tasks (paginated; optional `status`, `title` filters) |
| PUT    | `/{id}`           | Update a task                                  |
| DELETE | `/{id}`           | Delete a task                                  |

### Example: create a task

```bash
curl -X POST http://localhost:8080/api/v1/tasks \
  -H "Content-Type: application/json" \
  -d '{"title": "Write report", "description": "Q3 summary", "dueDate": "2026-10-01"}'
```

### Example: list in-progress tasks, page 2 of 10

```bash
curl "http://localhost:8080/api/v1/tasks?status=IN_PROGRESS&page=1&size=10"
```

### Error format

All errors return a consistent JSON shape:

```json
{
  "timestamp": "2026-09-18T10:00:00Z",
  "status": 404,
  "error": "Not Found",
  "message": "Task not found with id: 123",
  "path": "/api/v1/tasks/123"
}
```

Validation errors additionally include a `fieldErrors` map of field name to
message.

## Production hardening checklist

This project is a solid, professional starting point. Before shipping to
production, consider adding:

- A real database (Postgres/MySQL) + Flyway or Liquibase for schema migrations
  instead of `ddl-auto: update`
- Authentication/authorization (Spring Security + OAuth2/JWT)
- Rate limiting and request logging/correlation IDs
- Externalized, environment-specific configuration and secrets management
- CI pipeline running `mvn verify` (tests + static analysis) on every PR
- Structured logging and metrics export (e.g., Micrometer → Prometheus)
- API versioning strategy beyond the `/v1` prefix as the API grows

## Note on this build

This project was authored in a sandboxed environment without access to Maven
Central, so it could not be compiled and run here to confirm a green build.
The code was written and reviewed carefully against standard Spring Boot 3.3 /
Jakarta EE APIs, but please run `mvn clean verify` locally as a first step
after downloading.
